
This library is a wrapper around the excellent FreeType 2.0 library,
available at:
	http://www.freetype.org/

This library allows you to use TrueType fonts to render text in SDL
applications.

To make the library, first install the FreeType library, then type
'./configure' then 'make' to build the SDL truetype library and the
showfont and glfont example applications.

Be careful when including fonts with your application, as many of them
are copyrighted.  The Microsoft fonts, for example, are not freely 
redistributable and even the free "web" fonts they provide are only 
redistributable in their special executable installer form (May 1998).
There are plenty of freeware and shareware fonts available on the Internet
though, and may suit your purposes.

This library is under the zlib license, see the file "COPYING" for details.

Enjoy!
	-Sam Lantinga <slouken@libsdl.org>		(6/20/2001)
